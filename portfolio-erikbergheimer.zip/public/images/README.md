# og-image.jpg — 1200x630px für Social Sharing
