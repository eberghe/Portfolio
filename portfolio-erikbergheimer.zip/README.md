# Erik Bergheimer — Portfolio

UX/UI Designer & Webflow Expert · Innsbruck, Austria

## Tech Stack

| Tool | Zweck |
|------|-------|
| [Astro 4](https://astro.build) | Framework (SSG, blitzschnell, SEO-optimiert) |
| [Tailwind CSS 3](https://tailwindcss.com) | Utility-Klassen (additiv zu CSS Custom Props) |
| CSS Custom Properties | Design Tokens (tokens.css) |
| TypeScript | Daten & i18n |
| Netlify | Hosting + Domain Connect |

---

## Projekt starten

### Voraussetzungen
- Node.js ≥ 18 (prüfen: `node -v`)
- npm ≥ 9

### Setup

```bash
# 1. Repo klonen
git clone https://github.com/eberghe/Portfolio.git
cd Portfolio

# 2. Dependencies installieren
npm install

# 3. Dev-Server starten
npm run dev
# → http://localhost:4321
```

### Build & Preview

```bash
npm run build    # Produktions-Build in /dist
npm run preview  # Build lokal testen
```

---

## Projektstruktur

```
src/
├── layouts/
│   └── Layout.astro          # Haupt-Layout: Nav, Footer, SEO, Dark Mode
│
├── pages/
│   ├── index.astro           # Home (Deutsch, default)
│   ├── projekte.astro        # Projektübersicht
│   ├── projekte/
│   │   └── [slug].astro      # Dynamische Projekt-Detailseite
│   ├── ueber-mich.astro      # Über mich + Timeline
│   ├── kontakt.astro         # Kontakt + mailto-Formular
│   ├── services.astro        # Services + Bento Grid
│   ├── faqs.astro            # FAQs
│   └── en/                   # Englische Versionen (gleiche Struktur)
│
├── components/
│   ├── ProjectCard.astro     # Wiederverwendbare Projektkarte
│   ├── BentoCard.astro       # Service-Bento-Karte
│   ├── Timeline.astro        # Karriere-Timeline
│   └── ServiceCard.astro     # Service-Detailkarte
│
├── data/
│   └── projects.ts           # Alle Projekte, Timeline, Services, FAQs
│
├── i18n/
│   └── translations.ts       # DE/EN UI-Strings
│
└── styles/
    └── tokens.css            # CSS Custom Properties (Design Tokens)

public/
├── images/
│   ├── projects/             # Projektbilder (cover.jpg, detail-1.jpg ...)
│   │   ├── sightkick/
│   │   ├── cpr/
│   │   ├── indonesia/
│   │   ├── webflow-shopify/
│   │   └── morocco/
│   └── about/
│       └── portrait.jpg      # Dein Portrait
├── favicon.svg
└── og-image.jpg              # Open Graph Bild (1200×630px)
```

---

## Bilder einfügen

### Portrait (Über mich & Hero)
Ersetze den Platzhalter in `src/pages/index.astro` und `ueber-mich.astro`:
```html
<!-- ERSETZEN: -->
<div class="hero-ph">...</div>

<!-- MIT: -->
<img
  src="/images/about/portrait.jpg"
  alt="Portrait von Erik Bergheimer, UX/UI Designer aus Innsbruck"
  width="400"
  height="500"
  loading="eager"
/>
```

### Projektbilder
In `src/data/projects.ts` ist für jedes Projekt ein `slug` definiert.
Lege Bilder ab unter: `public/images/projects/{slug}/cover.jpg`

Ersetze in `src/pages/projekte/[slug].astro`:
```html
<!-- Platzhalter-Div raus, echtes Bild rein: -->
<img
  src={`/images/projects/${project.slug}/cover.jpg`}
  alt={projectData.imgAlt}
  width="880"
  height="440"
  loading="lazy"
/>
```

### Empfohlene Bildgrößen
| Bild | Größe | Format |
|------|-------|--------|
| Portrait | 400×500px | JPG/WebP |
| Projekt Cover (wide) | 880×440px | JPG/WebP |
| Projekt Cover (normal) | 440×320px | JPG/WebP |
| OG Image | 1200×630px | JPG |
| Favicon | 32×32px | SVG |

---

## Logo einfügen

Ersetze in `src/layouts/Layout.astro` den `.logo-sq` Platzhalter:
```html
<!-- ALT: -->
<div class="logo-sq" aria-hidden="true">EB</div>

<!-- NEU (SVG Logo): -->
<img src="/images/logo.svg" alt="Erik Bergheimer Logo" width="26" height="26" />

<!-- ODER (inline SVG für maximale Kontrolle): -->
<svg ...>dein Logo SVG...</svg>
```

---

## Design Tokens anpassen

Alle Farben und Spacing-Werte in `src/styles/tokens.css`:

```css
:root {
  --green:        #377566;   /* Primäre Akzentfarbe */
  --green-dark:   #2d6457;   /* Hover-Zustand */
  --green-light:  #eaf3ef;   /* Helle Hintergründe */
  --text:         #18252D;   /* Haupttext */
  ...
}
```

---

## Deployment (Netlify)

1. Netlify-Account erstellen: [netlify.com](https://netlify.com)
2. "Add new site" → "Import from Git" → GitHub → `Portfolio` Repo
3. Build settings:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
4. Deploy → automatisch bei jedem `git push`!
5. Domain: Settings → Domain Management → Add custom domain

---

## SEO Checkliste

- [x] Meta title & description pro Seite
- [x] Open Graph tags
- [x] Twitter Card
- [x] Schema.org JSON-LD (Person)
- [x] Canonical URLs
- [x] hreflang DE/EN
- [x] Semantisches HTML (h1→h2→h3 Hierarchie)
- [x] Alt-Texte für alle Bilder (Platzhalter vorhanden)
- [x] aria-label auf Links und Buttons
- [x] Skip-Link für Keyboard-Navigation
- [x] robots meta tag
- [ ] robots.txt hinzufügen (siehe unten)
- [ ] sitemap.xml (Astro sitemap integration)

### robots.txt hinzufügen
Erstelle `public/robots.txt`:
```
User-agent: *
Allow: /
Sitemap: https://erikbergheimer.com/sitemap-index.xml
```

### Sitemap aktivieren
In `astro.config.mjs`:
```js
import sitemap from '@astrojs/sitemap';
export default defineConfig({
  integrations: [tailwind(), sitemap()],
  site: 'https://erikbergheimer.com',
});
```
```bash
npm install @astrojs/sitemap
```

---

## Kontakt / Domain

- **E-Mail:** erb1209@outlook.de
- **Instagram:** [@erik.bergheimer](https://www.instagram.com/erik.bergheimer/)
- **LinkedIn:** [Erik Bergheimer](https://www.linkedin.com/in/erik-bergheimer-5856601ab/)
