// src/i18n/translations.ts
// All UI strings in German (default) and English

export const t = {
  de: {
    // Nav
    nav: {
      home:     'Home',
      projects: 'Projekte',
      services: 'Services',
      about:    'Über mich',
      contact:  'Kontakt',
      faqs:     'FAQs',
    },
    // Home Hero
    hero: {
      badge:    'Verfügbar für Projekte',
      h1_line1: 'Design,',
      h1_line2: 'das sich',
      h1_em:    'menschlich',
      h1_line3: 'anfühlt.',
      sub:      'UX/UI Designer & Webflow Expert aus Innsbruck. Ich schaffe digitale Erlebnisse, die Sinn ergeben, gut aussehen — und wirklich funktionieren.',
      cta_proj: 'Projekte ansehen',
      cta_contact: 'Kontakt',
      photo_alt: 'Portrait von Erik Bergheimer, UX/UI Designer aus Innsbruck',
    },
    stats: {
      exp:      'Jahre Erfahrung',
      projects: 'Projekte',
      countries:'Länder',
      location: 'Aktuell',
    },
    sections: {
      services:    'Was ich anbiete',
      sel_projects:'Ausgewählte Projekte',
      view_all:    'Alle ansehen →',
    },
    // About
    about: {
      meta_title: 'Über mich — Erik Bergheimer, UX/UI Designer',
      meta_desc:  'Empathischer UX Designer & Webflow Expert aus Innsbruck. Über meine Geschichte, meinen Werdegang und meine Arbeitsweise.',
      role:       'UX/UI Designer & Webflow Expert',
      location:   'Innsbruck · 25 Jahre · M.A. MCI',
      bio:        'Ich bin ein empathischer UX Designer und Webflow Expert, der digitale Erlebnisse schafft, die Sinn ergeben und sich menschlich anfühlen. Mein Weg führte mich von Königsbrunn über Neuseeland, Ingolstadt und Bali bis nach Innsbruck — jede Station hat meine Sicht auf Design und Arbeit geprägt.',
      journey:    'Mein Weg',
      photo_alt:  'Erik Bergheimer, UX Designer aus Innsbruck',
    },
    // Contact
    contact: {
      meta_title:  'Kontakt — Erik Bergheimer',
      meta_desc:   'Projekt, Idee oder einfach Hallo? Meld dich bei Erik Bergheimer, UX/UI Designer und Webflow Expert aus Innsbruck.',
      eyebrow:     'Lass uns reden',
      h1:          'Projekt? Idee? Einfach Hallo.',
      sub:         'Ich freue mich über neue Projekte, Kooperationen und interessante Gespräche. Ich melde mich in der Regel innerhalb von 24 Stunden.',
      direct:      'Direktkontakt',
      location_l:  'Standort',
      form_title:  'Nachricht senden',
      name:        'Name',
      name_ph:     'Dein Name',
      subject:     'Betreff',
      subject_ph:  'Worum geht es?',
      message:     'Nachricht',
      message_ph:  'Erzähl mir von deinem Projekt...',
      send:        '✉ Nachricht senden',
    },
    // Projects
    projects: {
      meta_title: 'Projekte — Erik Bergheimer',
      meta_desc:  'UX/UI Design, Fotografie und No-Code Projekte von Erik Bergheimer — CPR App, SIGHT\'KICK, Indonesia, Webflow vs. Shopify, Morocco.',
      h1:         'Projekte',
      sub:        'UX/UI Design, Fotografie & No-Code Development',
      back:       'Alle Projekte',
      similar:    'Ähnliches Projekt anfragen',
      visuals:    'Bildmaterial',
      type_l:     'Typ',
      role_l:     'Rolle',
      year_l:     'Jahr',
    },
    // Services
    services: {
      meta_title: 'Services — Erik Bergheimer',
      meta_desc:  'UX/UI Design, Webflow, Framer, Fotografie, Design Systems, Barrierefreiheit und Business Development — Services von Erik Bergheimer.',
      h1:         'Services',
      sub:        'Was ich für dich tun kann — von Konzept bis Launch.',
      core:       'Kernservice',
    },
    // FAQs
    faqs: {
      meta_title: 'FAQs — Erik Bergheimer',
      meta_desc:  'Häufig gestellte Fragen zu Zusammenarbeit, Projekten, Tools und Verfügbarkeit von Erik Bergheimer, UX Designer aus Innsbruck.',
      h1:         'FAQs',
      sub:        'Häufig gestellte Fragen',
    },
    // Footer
    footer: {
      copy: '© 2025 · UX/UI Designer & Webflow Expert',
    },
  },
  en: {
    nav: {
      home:     'Home',
      projects: 'Projects',
      services: 'Services',
      about:    'About',
      contact:  'Contact',
      faqs:     'FAQs',
    },
    hero: {
      badge:    'Available for projects',
      h1_line1: 'Design',
      h1_line2: 'that feels',
      h1_em:    'human.',
      h1_line3: '',
      sub:      'UX/UI Designer & Webflow Expert from Innsbruck. I create digital experiences that make sense, look sharp, and actually work.',
      cta_proj: 'View projects',
      cta_contact: 'Get in touch',
      photo_alt: 'Portrait of Erik Bergheimer, UX/UI Designer from Innsbruck',
    },
    stats: {
      exp:      'Years experience',
      projects: 'Projects',
      countries:'Countries',
      location: 'Currently',
    },
    sections: {
      services:    'What I offer',
      sel_projects:'Selected projects',
      view_all:    'View all →',
    },
    about: {
      meta_title: 'About — Erik Bergheimer, UX/UI Designer',
      meta_desc:  'Empathetic UX Designer & Webflow Expert from Innsbruck. About my story, career path and way of working.',
      role:       'UX/UI Designer & Webflow Expert',
      location:   'Innsbruck · 25 years old · M.A. MCI',
      bio:        "I'm an empathetic UX Designer and Webflow Expert who creates digital experiences that make sense and feel human. My journey took me from Königsbrunn through New Zealand, Ingolstadt and Bali to Innsbruck — each stop shaped my view on design and work.",
      journey:    'My journey',
      photo_alt:  'Erik Bergheimer, UX Designer from Innsbruck',
    },
    contact: {
      meta_title:  'Contact — Erik Bergheimer',
      meta_desc:   'Project, idea or just saying hi? Reach out to Erik Bergheimer, UX/UI Designer and Webflow Expert from Innsbruck.',
      eyebrow:     "Let's talk",
      h1:          'Project? Idea? Just say hi.',
      sub:         "I'm open to new projects, collaborations and interesting conversations. I usually respond within 24 hours.",
      direct:      'Direct contact',
      location_l:  'Location',
      form_title:  'Send a message',
      name:        'Name',
      name_ph:     'Your name',
      subject:     'Subject',
      subject_ph:  "What's it about?",
      message:     'Message',
      message_ph:  'Tell me about your project...',
      send:        '✉ Send message',
    },
    projects: {
      meta_title: 'Projects — Erik Bergheimer',
      meta_desc:  "UX/UI Design, Photography and No-Code projects by Erik Bergheimer — CPR App, SIGHT'KICK, Indonesia, Webflow vs. Shopify, Morocco.",
      h1:         'Projects',
      sub:        'UX/UI Design, Photography & No-Code Development',
      back:       'All projects',
      similar:    'Request a similar project',
      visuals:    'Visuals',
      type_l:     'Type',
      role_l:     'Role',
      year_l:     'Year',
    },
    services: {
      meta_title: 'Services — Erik Bergheimer',
      meta_desc:  'UX/UI Design, Webflow, Framer, Photography, Design Systems, Accessibility and Business Development — services by Erik Bergheimer.',
      h1:         'Services',
      sub:        'What I can do for you — from concept to launch.',
      core:       'Core service',
    },
    faqs: {
      meta_title: 'FAQs — Erik Bergheimer',
      meta_desc:  'Frequently asked questions about collaboration, projects, tools and availability of Erik Bergheimer, UX Designer from Innsbruck.',
      h1:         'FAQs',
      sub:        'Frequently asked questions',
    },
    footer: {
      copy: '© 2025 · UX/UI Designer & Webflow Expert',
    },
  },
} as const;

export type Lang = keyof typeof t;
export function useT(lang: Lang) { return t[lang]; }
