// src/data/projects.ts
export const projects = [
  {
    slug: 'sightkick',
    type: 'UX/UI · Gamification · Master',
    role: 'Lead UX Designer',
    year: '2024',
    tools: 'Figma · Service Design · User Research',
    bgClass: 'bg-blue',
    badge: 'Master Projekt',
    de: {
      title: "SIGHT'KICK",
      tagline: 'Gamifizierte Stadterkundung für Innsbruck',
      shortDesc: 'Gamifizierte Stadterkundungs-App für Innsbruck — klassisches Sightseeing neu gedacht.',
      body: [
        "Ich leitete die Entwicklung einer gamifizierten Stadterkundungs-App für Innsbruck — klassisches Sightseeing in eine personalisierte, abenteuerliche Quest verwandelt. Ein Kernprojekt aus meinem Masterstudium am MCI Innsbruck.",
        "Mit Challenges, Achievements und individuellen Routen erlebt der Nutzer die Stadt als aktiver Entdecker statt als passiver Tourist. Das Projekt vereinte Service Design, App-UX und Gamification-Methoden in einem kohärenten Erlebnis.",
      ],
      imgAlt: "SIGHT'KICK App — Gamifizierte Stadterkundung Innsbruck",
    },
    en: {
      title: "SIGHT'KICK",
      tagline: 'Gamified city exploration for Innsbruck',
      shortDesc: 'Gamified city exploration app for Innsbruck — classic sightseeing reimagined.',
      body: [
        "I led the creation of a gamified city exploration app for Innsbruck, turning classic sightseeing into a personalized, adventurous quest. A core project from my master's program at MCI Innsbruck.",
        "With challenges, achievements and individual routes, users experience the city as active explorers rather than passive tourists. The project combined service design, app UX and gamification methods.",
      ],
      imgAlt: "SIGHT'KICK App — Gamified city exploration Innsbruck",
    },
  },
  {
    slug: 'cpr',
    type: 'UX/UI · App Design',
    role: 'UX/UI Designer',
    year: '2023',
    tools: 'Figma · Prototyping · User Testing',
    bgClass: 'bg-teal',
    badge: 'App Design',
    de: {
      title: 'CPR App',
      tagline: 'Kinder als Lebensretter ausbilden',
      shortDesc: 'Kinder lernen lebensrettende Reanimationstechniken spielerisch.',
      body: [
        "CPR steht für Cardiopulmonary Reanimation — eine lebensrettende Notfallmaßnahme. Unser Ziel war es, Kindern spielerisch beizubringen, diese Technik zu erlernen und potenzielle Lebensretter zu werden.",
        "Durch gamifizierte Elemente, klare visuelle Anleitungen und eine intuitive Nutzerführung entstand eine App, die komplexe medizinische Abläufe für ein junges Publikum zugänglich macht. Der Prozess umfasste intensives User Research, Usability-Tests mit der Zielgruppe und mehrere Iterationsrunden.",
      ],
      imgAlt: 'CPR App — UX Design für lebensrettende Technik',
    },
    en: {
      title: 'CPR App',
      tagline: 'Training children as lifesavers',
      shortDesc: 'Children learn life-saving CPR techniques through play.',
      body: [
        "CPR stands for Cardiopulmonary Reanimation — a life-saving emergency procedure. Our goal was to help children learn this technique through play and become potential lifesavers.",
        "Through gamification, clear visual guides and intuitive UX, we created an app that makes complex medical procedures accessible to a young audience. The process involved intensive user research, usability testing with the target group and multiple iteration rounds.",
      ],
      imgAlt: 'CPR App — UX Design for life-saving technique',
    },
  },
  {
    slug: 'indonesia',
    type: 'Fotografie · Travel',
    role: 'Fotograf',
    year: '2024',
    tools: 'Sony Alpha · Adobe Lightroom',
    bgClass: 'bg-warm',
    badge: 'Fotografie',
    de: {
      title: 'Indonesia',
      tagline: 'Kultur & Landschaft durch mein Objektiv',
      shortDesc: 'Kultur & Landschaft Indonesiens durch mein Objektiv.',
      body: [
        "Eine visuelle Reise durch die lebendige Kultur und beeindruckenden Landschaften Indonesiens — entstanden während meiner Workation in Bali von Februar bis April 2024.",
        "Die Serie zeigt Alltag, sakrale Orte, Natur und Architektur — immer mit Blick für das Besondere im Gewöhnlichen. Bali hat meine Sicht auf Remote Work und kreatives Schaffen nachhaltig geprägt.",
      ],
      imgAlt: 'Indonesien Fotografie — Kultur und Landschaft von Erik Bergheimer',
    },
    en: {
      title: 'Indonesia',
      tagline: 'Culture & landscape through my lens',
      shortDesc: 'Culture & landscape of Indonesia through my lens.',
      body: [
        "A visual journey through the vibrant culture and stunning landscapes of Indonesia — created during my workation in Bali from February to April 2024.",
        "The series captures everyday life, sacred places, nature and architecture — finding the extraordinary in the ordinary. Bali profoundly shaped my view on remote work and creative expression.",
      ],
      imgAlt: 'Indonesia Photography — Culture and landscape by Erik Bergheimer',
    },
  },
  {
    slug: 'webflow-shopify',
    type: 'Web · No-Code · Bachelor Thesis',
    role: 'Researcher & Developer',
    year: '2023',
    tools: 'Webflow · Shopify · Research Methods',
    bgClass: 'bg-blue',
    badge: 'Bachelor Thesis',
    de: {
      title: 'Webflow vs. Shopify',
      tagline: 'Können No-Code Tools professionelle Shops liefern?',
      shortDesc: 'Können Low-/No-Code Tools professionelle Online-Shops ohne Code liefern?',
      body: [
        "Können Low-/No-Code Tools professionelle Online-Shops liefern, ohne eine einzige Zeile Code zu schreiben? Ich baute eine Marke auf zwei Plattformen, um es systematisch herauszufinden.",
        'Die Grundlage meiner Bachelorarbeit „Limitations and Problems of Low-/No-Code Tools in the Context of E-Commerce". Fazit: Beide Plattformen liefern beeindruckende Ergebnisse — mit sehr unterschiedlichen Stärken und klaren Grenzen.',
      ],
      imgAlt: 'Webflow vs Shopify — No-Code E-Commerce Vergleich',
    },
    en: {
      title: 'Webflow vs. Shopify',
      tagline: 'Can no-code tools deliver professional shops?',
      shortDesc: 'Can low-/no-code tools deliver professional online shops without code?',
      body: [
        "Can low-/no-code tools deliver professional online shops without a single line of code? I built one brand on two platforms to find out systematically.",
        'The foundation of my bachelor\'s thesis "Limitations and Problems of Low-/No-Code Tools in the Context of E-Commerce". Verdict: both platforms deliver impressive results — with very different strengths and clear limitations.',
      ],
      imgAlt: 'Webflow vs Shopify — No-Code E-Commerce comparison',
    },
  },
  {
    slug: 'morocco',
    type: 'Fotografie · Dokumentarisch',
    role: 'Fotograf',
    year: '2023',
    tools: 'Sony Alpha · Lightroom · Capture One',
    bgClass: 'bg-sand',
    badge: 'Fotografie',
    de: {
      title: 'Morocco',
      tagline: 'Alltag und Schönheit in Marokko',
      shortDesc: 'Texturen und Traditionen Marokkos — Alltag und atemberaubende Landschaften.',
      body: [
        "In die Texturen und Traditionen Marokkos eingetaucht — ich habe die Essenz des Alltags und atemberaubende Szenerie in einer Serie evokatativer Bilder festgehalten.",
        "Von den belebten Souks in Marrakesch bis zu stillen Wüstenlandschaften — diese Fotoserie erzählt von einem Land voller Kontraste, Farben und Geschichte.",
      ],
      imgAlt: 'Marokko Fotografie — Alltag und Landschaft von Erik Bergheimer',
    },
    en: {
      title: 'Morocco',
      tagline: 'Everyday life and beauty in Morocco',
      shortDesc: 'Textures and traditions of Morocco — everyday life and breathtaking landscapes.',
      body: [
        "Immersed in the textures and traditions of Morocco — I captured the essence of everyday life and breathtaking scenery in a series of evocative images.",
        "From the busy souks of Marrakech to quiet desert landscapes — this photo series tells of a land full of contrasts, colors and history.",
      ],
      imgAlt: 'Morocco Photography — Everyday life and landscape by Erik Bergheimer',
    },
  },
];

// Timeline data
export const timeline = [
  { date: 'Jul 2018', de: 'Abitur & IKEA', en: 'School diploma & IKEA', deSub: 'Königsbrunn, Deutschland', enSub: 'Königsbrunn, Germany' },
  { date: 'Okt 2018', de: 'Work & Travel — Neuseeland', en: 'Work & Travel — New Zealand', deSub: '6 Monate solo, voller Vorfreude', enSub: '6 months solo, full of excitement' },
  { date: 'Dez 2018', de: 'Kiwi-Farm in Te Puke', en: 'Kiwi farm in Te Puke', deSub: 'Erster Job in NZ — physische Arbeit, frische Luft', enSub: 'First job in NZ — physical work, fresh air' },
  { date: 'Jun 2019', de: 'Amazon Deutschland', en: 'Amazon Germany', deSub: 'Kapital für das Studium gespart', enSub: 'Saved up for university' },
  { date: 'Okt 2019', de: 'B.Sc. User Experience Design', en: 'B.Sc. User Experience Design', deSub: 'TH Ingolstadt, Deutschland', enSub: 'TH Ingolstadt, Germany' },
  { date: 'Okt 2021', de: 'Pflichtpraktikum @ TEAM23', en: 'Internship @ TEAM23', deSub: 'Augsburg — UX/UI Design', enSub: 'Augsburg — UX/UI Design' },
  { date: 'Feb 2022', de: 'Working Student @ TEAM23', en: 'Working student @ TEAM23', deSub: 'UX/UI Design · 4 Jahre', enSub: 'UX/UI Design · 4 years' },
  { date: 'Aug 2023', de: 'Bachelor Thesis', en: 'Bachelor thesis', deSub: 'Low-/No-Code Tools im E-Commerce', enSub: 'Low-/No-Code Tools in E-Commerce' },
  { date: 'Sep 2023', de: 'UX/UI Designer @ TEAM23 (Fulltime)', en: 'UX/UI Designer @ TEAM23 (full-time)', deSub: 'Augsburg, Deutschland', enSub: 'Augsburg, Germany' },
  { date: 'Feb 2024', de: 'Workation in Bali, Indonesien', en: 'Workation in Bali, Indonesia', deSub: 'Remote Work über Zeitzonen — prägend', enSub: 'Remote work across time zones — formative' },
  { date: 'Okt 2024', de: 'Umzug nach Innsbruck', en: 'Move to Innsbruck', deSub: 'M.A. Management, Communication & IT @ MCI', enSub: 'M.A. Management, Communication & IT @ MCI' },
  { date: 'Sep 2025', de: 'Working Student Biz Dev @ HERO Software', en: 'Working student biz dev @ HERO Software', deSub: 'Innsbruck — Neues Kapitel', enSub: 'Innsbruck — New chapter' },
];

// Services
export const services = [
  {
    icon: 'layout',
    featured: true,
    de: { name: 'UX/UI Design', desc: 'Von Research über Wireframes bis zum fertigen Prototypen. Nutzerzentriert, zugänglich und auf den Punkt — von der ersten Idee bis zur finalen Übergabe.' },
    en: { name: 'UX/UI Design', desc: 'From research through wireframes to the final prototype. User-centered, accessible and on point — from the first idea to the final developer handoff.' },
    tags: ['Figma', 'Prototyping', 'User Research', 'Usability Testing', 'Wireframing'],
  },
  {
    icon: 'monitor',
    featured: false,
    de: { name: 'Webflow & Framer', desc: 'Pixel-perfekte, animierte Websites. CMS-ready, performant und ohne Code-Overhead.' },
    en: { name: 'Webflow & Framer', desc: 'Pixel-perfect, animated websites. CMS-ready, performant and without code overhead.' },
    tags: ['Webflow', 'Framer', 'CMS'],
  },
  {
    icon: 'camera',
    featured: false,
    de: { name: 'Fotografie', desc: 'Travel, Kultur, Editorial — Bilder, die Geschichten erzählen.' },
    en: { name: 'Photography', desc: 'Travel, culture, editorial — images that tell stories.' },
    tags: ['Travel', 'Editorial', 'Lightroom'],
  },
  {
    icon: 'grid',
    featured: false,
    de: { name: 'Design Systems', desc: 'Skalierbare, token-basierte Komponentenbibliotheken für konsistente Produkte.' },
    en: { name: 'Design Systems', desc: 'Scalable, token-based component libraries for consistent products.' },
    tags: ['Tokens', 'Components', 'Docs'],
  },
  {
    icon: 'accessibility',
    featured: false,
    de: { name: 'Barrierefreiheit', desc: 'WCAG-Audits und konforme Interfaces für alle Nutzergruppen.' },
    en: { name: 'Accessibility', desc: 'WCAG audits and compliant interfaces for all user groups.' },
    tags: ['WCAG 2.1', 'Audit', 'A11y'],
  },
  {
    icon: 'trending-up',
    featured: false,
    de: { name: 'Business Development', desc: 'Strategischer Support, digitale Positionierung & Partnerships.' },
    en: { name: 'Business Development', desc: 'Strategic support, digital positioning & partnerships.' },
    tags: ['Strategie', 'Partnerships'],
  },
];

// FAQs
export const faqs = [
  {
    de: { q: 'Welche Services bietest du an?', a: 'UX/UI Design, Webflow/Framer Development, Fotografie, Design Systems, Barrierefreiheitsberatung und Business Development Support.' },
    en: { q: 'What services do you offer?', a: 'UX/UI Design, Webflow/Framer Development, Photography, Design Systems, Accessibility consulting and Business Development support.' },
  },
  {
    de: { q: 'Arbeitest du remote?', a: 'Ja, vollständig remote-fähig — bewiesen während meiner Workation in Bali. Ich bin auch offen für Vor-Ort-Termine in und um Innsbruck.' },
    en: { q: 'Do you work remotely?', a: "Yes, fully remote-capable — proven during my workation in Bali. I'm also open for on-site meetings in and around Innsbruck." },
  },
  {
    de: { q: 'Wie läuft ein Projekt typischerweise ab?', a: 'Kennenlerngespräch → Briefing → iteratives Design mit Reviews → Feedback → Finalisierung & Asset-Übergabe.' },
    en: { q: 'How does a project typically run?', a: 'Discovery call → briefing → iterative design with reviews → feedback → finalization & asset handoff.' },
  },
  {
    de: { q: 'Welche Tools nutzt du?', a: 'Figma, Webflow, Framer, Adobe Lightroom, Capture One, Notion.' },
    en: { q: 'What tools do you use?', a: 'Figma, Webflow, Framer, Adobe Lightroom, Capture One, Notion.' },
  },
  {
    de: { q: 'Wie lange dauert ein Projekt?', a: 'Landing Page: 1–2 Wochen. Vollständiges UX-Projekt: 4–8 Wochen. Timelines kommuniziere ich von Beginn an transparent.' },
    en: { q: 'How long does a project take?', a: "Landing page: 1–2 weeks. Full UX project: 4–8 weeks. I communicate timelines transparently from day one." },
  },
  {
    de: { q: 'Bist du aktuell verfügbar?', a: 'Ja! Schreib mir — ich melde mich normalerweise innerhalb von 24 Stunden.' },
    en: { q: 'Are you currently available?', a: 'Yes! Reach out — I usually respond within 24 hours.' },
  },
];
